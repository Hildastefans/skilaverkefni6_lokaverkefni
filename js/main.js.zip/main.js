var question_container = document.querySelector(".question_container")
var nextQuestion = document.querySelector("#addCardButton")
var tryAgainButton = document.querySelector("#tryAgain")




var quiz = [
    {
      options: [
        {
          option: 'Number 999',
          answered: false
        },
        {
          option: 'Number 742',
          answered: true
        },
        {
          option: 'Number 675',
          answered: false
        },
      ],
      spurning: 'What is the house number of the Simpsons?',
      img: "https://upload.wikimedia.org/wikipedia/en/thumb/c/ca/742_Evergreen_Terrace.png/300px-742_Evergreen_Terrace.png"
  },
  {
    options: [
      {
        option: 'Arnold Schwarzenegger',
        answered: false,
        
      },
      {
        option: 'Rob Bowman',
        answered: false
      },
      {
        option: 'Quentin Tarantino',
        answered: true
      },
    ],
    spurning: 'Who is the director of Reservoir Dogs?',
    img: "http://ichef.bbci.co.uk/wwfeatures/wm/live/1280_640/images/live/p0/4p/t6/p04pt626.jpg",
  },
  {
    options: [
      {
        option: 'Whoopi Goldberg',
        answered: true,
        
      },
      {
        option: 'Sarah Bernhardt',
        answered: false
      },
      {
        option: 'Julia Roberts',
        answered: false
      },
    ],
    spurning: 'Who was the leading actress in Sister act I en II ?',
    img: "https://i.ytimg.com/vi/ctjG4MjJwEA/maxresdefault.jpg",
  },
  {
    options: [
      {
        option: 'Austria',
        answered: false
      },
      {
        option: 'Switzerland',
        answered: false
      },
      {
        option: 'Belgium',
        answered: true
      },
    ],
    spurning: 'Which country is the origin of the Stella beer?',
    img: "https://d18lkz4dllo6v2.cloudfront.net/cumulus_uploads/entry/20808/peroni.png?w=660",
  },
  {
    options: [
      {
        option: 'Aaron',
        answered: true,
        
      },
      {
        option: 'Ben',
        answered: false
      },
      {
        option: 'Sam',
        answered: false
      },
    ],
    spurning: 'What is Elvis Presley s middle name?',
    img: "https://images.spot.im/v1/production/bkq5xa9a430ksbsgr3cj",
  },
  {
    options: [
      {
        option: 'Mariah Carey',
        answered: false,
        
      },
      {
        option: 'Whitney Houston',
        answered: false
      },
      {
        option: 'Aretha Franklin',
        answered: true
      },
    ],
    spurning: 'Who was the Queen of Soul?',
    img: "https://i.ytimg.com/vi/uvSNwjpFW8w/maxresdefault.jpg",
  },
  {
    options: [
      {
        option: 'Madonna Del Ciccone',
        answered: false
      },
      {
        option: 'Madonna Louise Ciccone',
        answered: true
      },
      {
        option: 'Madonna Alex Ciccone',
        answered: false
      },
    ],
    spurning: 'What is Madonna s full name',
    img: "https://www.irishexaminer.com/remote/media.central.ie/media/images/m/MadonnaAt60_large.jpg?width=648&s=ie-854852",
  },
  {
    options: [
      {
        option: 'Madrid',
        answered: false
      },
      {
        option: 'Barcelona',
        answered: true
      },
      {
        option: 'San Sebastian',
        answered: false
      },
    ],
    spurning: 'In which Spanish city did the Joan Miro museum open in 1975?',
    img: "https://www.moma.org/media/W1siZiIsIjM5Mzk4OCJdLFsicCIsImNvbnZlcnQiLCItcmVzaXplIDIwMDB4MjAwMFx1MDAzZSJdXQ.jpg?sha=f0f02397fa966814",
  },
  {
    options: [
      {
        option: 'Liverpool',
        answered: true,
        
      },
      {
        option: 'London',
        answered: false,
      },
      {
        option: 'Manchester',
        answered: false
      },
    ],
    spurning: 'In which English town did Adolf Hitler study art?',
    img: "https://d.ibtimes.co.uk/en/full/1462488/hitler-paintings.jpg?w=736&e=34da0cd97452faf28ac9ceda58b3d50c",
  },
]






var question_card = function(quiz){
  console.log(quiz)

  var options = '<form>'
  for( var i = 0; i < quiz.options.length; i++){
    options += `<input name="options" class="radioInput" type="radio"> ${quiz.options[i].option}` // hvar erum við að taka inn svar gildið?
  }
  options += '</form>'

  console.log(options)
  /** bæta við div-ið auka korti */
  question_container.innerHTML += `
      <div class= "card" >
          <img src="${quiz.img}" alt="">
          <h1>${quiz.spurning}</h1>
          <p> ${options} </p>
          </div>
          `   
        }
        
        question_card(quiz[0])
        
        
        
        var currentPage = 0
        var stig = 0
        
        var nextCard = function(){
          
          var radioButtons = document.getElementsByClassName("radioInput")
          
          var somethingIsChecked = false
          for(var i = 0; i < quiz[currentPage].options.length; i++){
            console.log("array:",quiz[currentPage].options[i].answered === true)
            console.log("radiobutton:",radioButtons[i].checked)
            if(quiz[currentPage].options[i].answered === true && radioButtons[i].checked === true){
              stig += 1
              console.log(stig)
              console.log(quiz)
            } 
            
            if (radioButtons[i].checked === true){
              somethingIsChecked = true 
              
            }
  }
if (!somethingIsChecked){
    alert("You need to answer!")
    return
} 

  if(currentPage < quiz.length -1){
    currentPage += 1
  }
  else {
    question_container.innerHTML = ''
      console.log ("theend")
      document.body.innerHTML = `<div class = "question_container" class="last_page"> 
      <h1>Þú hefur svarað ${stig} spurningum rétt!></h1>
      <button class="button" id="tryAgain" value="Try Again" onClick="window.location.href=window.location.href"/>Try Again!</button>
      </div>`
      
  } 
  question_container.innerHTML = ''




  question_card(quiz[currentPage])
  
}

var previous = function(){
    console.log ()
    question_container.innerHTML = ''
    if (currentPage > 0){
    currentPage -= 1 
  }  

  question_card(quiz[currentPage])

}


nextQue.onclick = nextCard
prevQuestion.onclick = previous





















